# Sidebar Menu With Curves
## [Watch it on youtube](https://youtu.be/3zPFXCa3kzI)
### Sidebar Menu With Curves

- Sidebar Menu With Curves Using HTML CSS & JavaScript
- With curves using only CSS.
- Floating names when hovering over icons.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
